<?php

namespace Amasty\RequestQuote\Block\Cart\Quote;

class Link extends \Magento\Framework\View\Element\Template
{
    /**
     * @return string
     */
    public function getQuoteSubmitUrl()
    {
        return $this->getUrl('amasty_quote/cart/submit');
    }
}
