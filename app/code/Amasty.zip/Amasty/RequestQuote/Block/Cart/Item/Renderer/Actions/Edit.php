<?php

namespace Amasty\RequestQuote\Block\Cart\Item\Renderer\Actions;

class Edit extends \Magento\Checkout\Block\Cart\Item\Renderer\Actions\Edit
{
    /**
     * @return string
     */
    public function getConfigureUrl()
    {
        return $this->getUrl(
            'amasty_quote/cart/configure',
            [
                'id' => $this->getItem()->getId(),
                'product_id' => $this->getItem()->getProduct()->getId()
            ]
        );
    }
}
