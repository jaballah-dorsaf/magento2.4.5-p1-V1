<?php

namespace Amasty\RequestQuote\Block\Cart\Item\Renderer;

class Actions extends \Magento\Checkout\Block\Cart\Item\Renderer\Actions
{
}
