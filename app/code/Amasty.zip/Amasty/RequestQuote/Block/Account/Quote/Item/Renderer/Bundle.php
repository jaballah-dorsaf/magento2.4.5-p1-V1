<?php

namespace Amasty\RequestQuote\Block\Account\Quote\Item\Renderer;

use Amasty\RequestQuote\Traits\Account\Quote\PriceRenderer;

class Bundle extends \Magento\Bundle\Block\Checkout\Cart\Item\Renderer
{
    use PriceRenderer;
}
