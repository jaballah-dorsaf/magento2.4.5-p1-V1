<?php

namespace Amasty\RequestQuote\Block\Adminhtml\Quote\Create\Totals;

class Tax extends DefaultTotals
{
    /**
     * @var string
     */
    protected $_template = 'Amasty_RequestQuote::quote/create/totals/tax.phtml';
}
