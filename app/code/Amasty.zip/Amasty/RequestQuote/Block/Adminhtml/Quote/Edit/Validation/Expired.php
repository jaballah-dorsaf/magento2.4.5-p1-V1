<?php

namespace Amasty\RequestQuote\Block\Adminhtml\Quote\Edit\Validation;

class Expired extends \Magento\Backend\Block\Template
{
    /**
     * @return bool
     */
    public function toHtml()
    {
        return true;
    }
}
