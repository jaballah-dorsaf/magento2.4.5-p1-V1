<?php

namespace Amasty\RequestQuote\Block\Adminhtml\Quote\View;

class History extends \Magento\Backend\Block\Template
{
    /**
     * @var \Amasty\RequestQuote\Model\Quote\Backend\Session
     */
    private $quoteSession;

    /**
     * @var \Magento\Framework\DataObjectFactory
     */
    private $dataObjectFactory;

    /**
     * @var \Amasty\Base\Model\Serializer
     */
    private $serializer;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Amasty\RequestQuote\Model\Quote\Backend\Session $quoteSession,
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        \Amasty\Base\Model\Serializer $serializer,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->quoteSession = $quoteSession;
        $this->dataObjectFactory = $dataObjectFactory;
        $this->serializer = $serializer;
    }

    /**
     * @return \Amasty\RequestQuote\Api\Data\QuoteInterface
     */
    public function getQuote()
    {
        return $this->quoteSession->getQuote();
    }

    /**
     * @return \Amasty\RequestQuote\Model\Quote\Backend\Session
     */
    public function getQuoteSession()
    {
        return $this->quoteSession;
    }

    /**
     * Check allow to add comment
     *
     * @return bool
     */
    public function canAddComment()
    {
        return !$this->getNotes()->getAdminNote();
    }

    /**
     * @return \Magento\Framework\DataObject
     */
    public function getNotes()
    {
        if (!$this->getData('notes')) {
            if ($remarks = $this->getQuote()->getRemarks()) {
                $remarks = $this->serializer->unserialize($remarks);
                $this->setData('notes', $this->dataObjectFactory->create(['data' => $remarks]));
            } else {
                $this->setData('notes', $this->dataObjectFactory->create());
            }
        }
        return $this->getData('notes'); 
    }
    public function getTelephones()
    {
        if (!$this->getData('telephones')) {
            if ($telephones = $this->getQuote()->getTelephones()) {
                $telephones = $this->serializer->unserialize($telephones);
                $this->setData('telephones', $this->dataObjectFactory->create(['data' => $telephones]));
            } else {
                $this->setData('telephones', $this->dataObjectFactory->create());
            }
        }
        return $this->getData('telephones'); 
    }
    public function getTels()
    {
        if (!$this->getData('tels')) {
            if ($tels = $this->getQuote()->getTels()) {
                $tels = $this->serializer->unserialize($tels);
                $this->setData('tels', $this->dataObjectFactory->create(['data' => $tels]));
            } else {
                $this->setData('tels', $this->dataObjectFactory->create());
            }
        }
        return $this->getData('tels'); 
    }

    public function getMatriculefiscales()
    {
        if (!$this->getData('matriculefiscales')) {
            if ($matriculefiscales = $this->getQuote()->getMatriculefiscales()) {
                $matriculefiscales = $this->serializer->unserialize($matriculefiscales);
                $this->setData('matriculefiscales', $this->dataObjectFactory->create(['data' => $matriculefiscales]));
            } else {
                $this->setData('matriculefiscales', $this->dataObjectFactory->create());
            }
        }
        return $this->getData('matriculefiscales'); 
    }

    public function getSocietes()
    {
        if (!$this->getData('societes')) {
            if ($societes = $this->getQuote()->getSocietes()) {
                $societes = $this->serializer->unserialize($societes);
                $this->setData('societes', $this->dataObjectFactory->create(['data' => $societes]));
            } else {
                $this->setData('societes', $this->dataObjectFactory->create());
            }
        }
        return $this->getData('societes'); 
    }
}
