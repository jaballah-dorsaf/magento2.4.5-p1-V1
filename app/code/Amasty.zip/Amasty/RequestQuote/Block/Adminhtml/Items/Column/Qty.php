<?php

namespace Amasty\RequestQuote\Block\Adminhtml\Items\Column;

class Qty extends \Amasty\RequestQuote\Block\Adminhtml\Items\Column\DefaultColumn
{
}
