<?php

namespace Amasty\RequestQuote\Block\Email;

class Items extends \Magento\Sales\Block\Items\AbstractItems
{
}
