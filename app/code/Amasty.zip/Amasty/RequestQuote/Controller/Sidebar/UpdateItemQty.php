<?php

namespace Amasty\RequestQuote\Controller\Sidebar;

class UpdateItemQty extends \Magento\Checkout\Controller\Sidebar\UpdateItemQty
{
}
