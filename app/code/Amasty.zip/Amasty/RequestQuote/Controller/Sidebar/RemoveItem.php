<?php

namespace Amasty\RequestQuote\Controller\Sidebar;

class RemoveItem extends \Magento\Checkout\Controller\Sidebar\RemoveItem
{
}
