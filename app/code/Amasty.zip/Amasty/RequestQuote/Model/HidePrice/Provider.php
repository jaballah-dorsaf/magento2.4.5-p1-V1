<?php

namespace Amasty\RequestQuote\Model\HidePrice;

use Magento\Catalog\Api\Data\ProductInterface;

class Provider
{
    /**
     * @param ProductInterface $product
     * @return bool
     */
    public function isHidePrice(ProductInterface $product)
    {
        return false;
    }
}
