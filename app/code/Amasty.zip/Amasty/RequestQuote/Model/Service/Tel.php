<?php

namespace Amasty\RequestQuote\Model\Service;

class Tel
{
    /**
     * @var \Amasty\RequestQuote\Model\Quote\Session
     */
    private $checkoutSession;

    /**
     * @var \Amasty\RequestQuote\Helper\Cart
     */
    private $cartHelper;

    public function __construct(
        \Amasty\RequestQuote\Model\Quote\Session $checkoutSession,
        \Amasty\RequestQuote\Helper\Cart $cartHelper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cartHelper = $cartHelper;
    }

    /**
     * @param string $tel 
     *
     * @return void
     */
    public function save($tel)
    {
        $tel = $this->cartHelper->prepareCustomerTelForSave($tel);
        $this->checkoutSession->getQuote()->setTel($tel)->save();
    }
}
