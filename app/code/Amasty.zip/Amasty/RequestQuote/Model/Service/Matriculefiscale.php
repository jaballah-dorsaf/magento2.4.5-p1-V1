<?php

namespace Amasty\RequestQuote\Model\Service;

class Matriculefiscale
{
    /**
     * @var \Amasty\RequestQuote\Model\Quote\Session
     */
    private $checkoutSession;

    /**
     * @var \Amasty\RequestQuote\Helper\Cart
     */
    private $cartHelper;

    public function __construct(
        \Amasty\RequestQuote\Model\Quote\Session $checkoutSession,
        \Amasty\RequestQuote\Helper\Cart $cartHelper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cartHelper = $cartHelper;
    }

    /**
     * @param string $matriculefiscale 
     *
     * @return void
     */
    public function save($matriculefiscale)
    {
        $matriculefiscale = $this->cartHelper->prepareCustomerMatriculefiscaleForSave($matriculefiscale);
        $this->checkoutSession->getQuote()->setMatriculefiscale($matriculefiscale)->save();
    }
}
