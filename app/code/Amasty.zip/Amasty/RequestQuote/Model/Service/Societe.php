<?php

namespace Amasty\RequestQuote\Model\Service;

class Societe
{
    /**
     * @var \Amasty\RequestQuote\Model\Quote\Session
     */
    private $checkoutSession;

    /**
     * @var \Amasty\RequestQuote\Helper\Cart
     */
    private $cartHelper;

    public function __construct(
        \Amasty\RequestQuote\Model\Quote\Session $checkoutSession,
        \Amasty\RequestQuote\Helper\Cart $cartHelper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cartHelper = $cartHelper;
    }

    /**
     * @param string $societe 
     *
     * @return void
     */
    public function save($societe)
    {
        $societe = $this->cartHelper->prepareCustomersocieteForSave($societe);
        $this->checkoutSession->getQuote()->setSociete($societe)->save();
    }
}
