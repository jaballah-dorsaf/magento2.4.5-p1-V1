<?php

namespace Amasty\RequestQuote\Model\Service;

class Telephone
{
    /**
     * @var \Amasty\RequestQuote\Model\Quote\Session
     */
    private $checkoutSession;

    /**
     * @var \Amasty\RequestQuote\Helper\Cart
     */
    private $cartHelper;

    public function __construct(
        \Amasty\RequestQuote\Model\Quote\Session $checkoutSession,
        \Amasty\RequestQuote\Helper\Cart $cartHelper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cartHelper = $cartHelper;
    }

    /**
     * @param string $telephone 
     *
     * @return void
     */
    public function save($telephone)
    {
        $telephone = $this->cartHelper->prepareCustomerTelephoneForSave($telephone);
        $this->checkoutSession->getQuote()->setTelephone($telephone)->save();
    }
}
