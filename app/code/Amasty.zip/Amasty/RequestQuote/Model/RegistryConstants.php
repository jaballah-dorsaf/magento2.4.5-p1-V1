<?php

declare(strict_types=1);

namespace Amasty\RequestQuote\Model;

class RegistryConstants
{
    const AMASTY_QUOTE = 'amasty_quote';
}
