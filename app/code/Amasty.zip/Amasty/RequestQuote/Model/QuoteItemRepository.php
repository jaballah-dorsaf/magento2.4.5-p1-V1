<?php

namespace Amasty\RequestQuote\Model;

use Amasty\Base\Model\Serializer;
use Amasty\RequestQuote\Api\Data\QuoteItemInterface;
use Amasty\RequestQuote\Api\QuoteItemRepositoryInterface;
use Amasty\RequestQuote\Model\ResourceModel\Quote\Item as ItemResource;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\ItemFactory;

/**
 * Class QuoteItemRepository
 */
class QuoteItemRepository implements QuoteItemRepositoryInterface
{
    /**
     * @var ItemFactory
     */
    private $itemFactory;

    /**
     * @var Serializer
     */
    private $serializer;

    /**
     * @var ItemResource
     */
    private $itemResource;

    public function __construct(
        ItemFactory $itemFactory,
        Serializer $serializer,
        ItemResource $itemResource
    ) {
        $this->itemFactory = $itemFactory;
        $this->serializer = $serializer;
        $this->itemResource = $itemResource;
    }

    /**
     * {@inheritdoc}
     */
    public function addCustomerNote($quoteItemId, $note)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::CUSTOMER_NOTE_KEY, $note);
    } 

    /**
     * {@inheritdoc}
     */
    public function addCustomerTelephone($quoteItemId, $telephone)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::CUSTOMER_TELEPHONE_KEY, $telephone);
    } 

     /**
     * {@inheritdoc}
     */
    public function addCustomerTel($quoteItemId, $tel)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::CUSTOMER_TEL_KEY, $tel);
    } 
  
        /**
     * {@inheritdoc}
     */
    public function addCustomerMatriculefiscale($quoteItemId, $matriculefiscale)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::CUSTOMER_MATRICULEFISCALE_KEY, $matriculefiscale);
    } 

        /**
     * {@inheritdoc}
     */
    public function addCustomerSociete($quoteItemId, $societe)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::CUSTOMER_SOCIETE_KEY, $societe);
    }


    /**
     * {@inheritdoc}
     */
    public function addAdminNote($quoteItemId, $note)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::ADMIN_NOTE_KEY, $note);
    }


    /**
     * {@inheritdoc}
     */
    public function addAdminTelephone($quoteItemId, $telephone)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::ADMIN_TELEPHONE_KEY, $telephone);
    }

    /**
     * {@inheritdoc}
     */
    public function addAdminTel($quoteItemId, $tel)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::ADMIN_TEL_KEY, $tel);
    }

    /**
     * {@inheritdoc}
     */
    public function addAdminMatriculefiscale($quoteItemId, $matriculefiscale)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::ADMIN_MATRICULEFISCALE_KEY, $matriculefiscale);
    }

     /**
     * {@inheritdoc}
     */
    public function addAdminSociete($quoteItemId, $societe)
    {
        return $this->updateAdditinalData($quoteItemId, QuoteItemInterface::ADMIN_SOCIETE_KEY, $societe);
    }

    /**
     * @param int $quoteItemId
     * @param string $key
     * @param string $note
     * @param string $telephone
     * @param string $tel
     * @param string $matriculefiscale
     * @param string $societe
     
     *
     * @return bool
     */
    private function updateAdditinalData($quoteItemId, $key, $note, $telephone, $tel, $matriculefiscale, $societe)
    {
        $result = true;
        try {
            /** @var Item $quote */
            $item = $this->itemFactory->create()
                ->load($quoteItemId);
            $additinalData = $item->getAdditionalData()
                ? $this->serializer->unserialize($item->getAdditionalData())
                : [];
            $additinalData[$key] = $societe;
            $this->itemResource->updateAdditinalData(
                $item->getId(),
                $this->serializer->serialize($additinalData)
            );
        } catch (\Exception $e) {
            $result = false;
        }

        return $result;
    }



    
}
