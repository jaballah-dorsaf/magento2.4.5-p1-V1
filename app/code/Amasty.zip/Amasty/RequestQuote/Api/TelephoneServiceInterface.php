<?php

namespace Amasty\RequestQuote\Api;

/**
 * Interface TelephoneServiceInterface
 */
interface TelephoneServiceInterface
{
    /**
     * @param string $telephone
     *
     * @return void
     */
    public function save($telephone);
} 
