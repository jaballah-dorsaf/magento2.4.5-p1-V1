<?php

namespace Amasty\RequestQuote\Api;

/**
 * Interface RemarkServiceInterface
 */
interface RemarkServiceInterface
{
    /**
     * @param string $remark
     *
     * @return void
     */
    public function save($remark);
}
