<?php

namespace Amasty\RequestQuote\Api\Data;

interface QuoteItemInterface
{
    const ADMIN_NOTE_KEY = 'admin_note';
    const ADMIN_TELEPHONE_KEY = 'admin_telephone';
    const ADMIN_TEL_KEY = 'admin_tel';
    const ADMIN_MATRICULEFISCALE_KEY = 'admin_matriculefiscale';
    const ADMIN_SOCIETE_KEY = 'admin_societe';
    const CUSTOMER_NOTE_KEY = 'customer_note';
    const CUSTOMER_TELEPHONE_KEY = 'customer_telephone';
    const CUSTOMER_TEL_KEY = 'customer_tel';
    const CUSTOMER_MATRICULEFISCALE_KEY = 'customer_matriculefiscale';
    const CUSTOMER_SOCIETE_KEY = 'customer_societe';
    const REQUESTED_PRICE = 'requested_price';
    const CUSTOM_PRICE = 'requested_custom_price';
    const HIDE_ORIGINAL_PRICE = 'hide_original_price';
}
