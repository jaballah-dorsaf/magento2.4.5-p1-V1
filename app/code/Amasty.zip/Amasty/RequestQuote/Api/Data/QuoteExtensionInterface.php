<?php

declare(strict_types=1);

namespace Amasty\RequestQuote\Api\Data;

interface QuoteExtensionInterface extends \Magento\Quote\Api\Data\CartExtensionInterface
{

}
