<?php

namespace Amasty\RequestQuote\Api\Data;

use Magento\Quote\Api\Data\CartExtensionInterface;
use Magento\Quote\Api\Data\CartInterface;

interface QuoteInterface extends CartInterface
{
    const MAIN_TABLE = 'amasty_quote';

    const STATUS = 'status';
    const EXPIRED_DATE = 'expired_date';
    const REMINDER_DATE = 'reminder_date';
    const ADMIN_NOTIFICATION_SEND = 'admin_notification_send';
    const ADMIN_NOTE_KEY = 'admin_note';
    const ADMIN_TELEPHONE_KEY = 'admin_telephone';
    const ADMIN_TEL_KEY = 'admin_tel';
    const ADMIN_MATRICULEFISCALE_KEY = 'admin_matriculefiscale';
    const ADMIN_SOCIETE_KEY = 'admin_societe';
    const CUSTOMER_NOTE_KEY = 'customer_note';
    const CUSTOMER_TELEPHONE_KEY = 'customer_telephone';
    const CUSTOMER_TEL_KEY = 'customer_tel';
    const CUSTOMER_MATRICULEFISCALE_KEY = 'customer_matriculefiscale';
    const CUSTOMER_SOCIETE_KEY = 'customer_societe';
    const DISCOUNT = 'discount';
    const SURCHARGE = 'surcharge';
    const REMINDER_SEND = 'reminder_send';
    const SUBMITED_DATE = 'submited_date';
    const SHIPPING_CAN_BE_MODIFIED = 'shipping_can_modified';
    const SHIPPING_CONFIGURE = 'shipping_configured';
    const CUSTOM_FEE = 'custom_fee';
    const CUSTOM_METHOD_ENABLED = 'custom_method_enabled';
    const SUM_ORIGINAL_PRICE = 'sum_original_price';

    /**
     * Retrieve existing extension attributes object or create a new one.
     *
     * @return \Amasty\RequestQuote\Api\Data\QuoteExtensionInterface|CartExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     *
     * @param \Amasty\RequestQuote\Api\Data\QuoteExtensionInterface|CartExtensionInterface $extensionAttributes
     *
     * @return $this
     */
    public function setExtensionAttributes(CartExtensionInterface $extensionAttributes);
}
