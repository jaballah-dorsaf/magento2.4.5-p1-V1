<?php

namespace Amasty\RequestQuote\Api;

/**
 * Interface QuoteItemRepositoryInterface
 */
interface QuoteItemRepositoryInterface
{
    /**
     * @param int $quoteItemId
     * @param string $note
     * @return bool
     */
    public function addCustomerNote($quoteItemId, $note);

    /**
     * @param int $quoteItemId
     * @param string $note
     * @return bool
     */
    public function addAdminNote($quoteItemId, $note);



    /**
     * @param int $quoteItemId
     * @param string $telephone
     * @return bool
     */
    public function addCustomerTelephone($quoteItemId, $telephone);

    /**
     * @param int $quoteItemId
     * @param string $telephone
     * @return bool
     */
    public function addAdminTelephone($quoteItemId, $telephone);

    /**
     * @param int $quoteItemId
     * @param string $tel
     * @return bool
     */
    public function addCustomerTel($quoteItemId, $tel);

    /**
     * @param int $quoteItemId
     * @param string $tel
     * @return bool
     */
    public function addAdminTel($quoteItemId, $tel);


     /**
     * @param int $quoteItemId
     * @param string $matriculefiscale
     * @return bool
     */
    public function addCustomerMatriculefiscale($quoteItemId, $matriculefiscale);

    /**
     * @param int $quoteItemId
     * @param string $matriculefiscale
     * @return bool
     */
    public function addAdminMatriculefiscale($quoteItemId, $matriculefiscale);


    /**
     * @param int $quoteItemId
     * @param string $societe
     * @return bool
     */
    public function addCustomerSociete($quoteItemId, $societe);

    /**
     * @param int $quoteItemId
     * @param string $societe
     * @return bool
     */
    public function addAdminSociete($quoteItemId, $societe);
}
