<?php

namespace Amasty\RequestQuote\Api;

/**
 * Interface TelServiceInterface
 */
interface TelServiceInterface
{
    /**
     * @param string $tel
     *
     * @return void
     */
    public function save($tel);
} 
