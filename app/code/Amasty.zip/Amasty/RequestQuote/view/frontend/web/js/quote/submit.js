define([
    'jquery'
], function ($) {
    'use strict';

    return function (config, element) {
        var form = $('.amasty-quote-update');
        $(element).click(function (event) {
            event.preventDefault();
            var detailsForm = $('[data-form-js="am-details-form"]'),
                eventData = {isValid: true};

            eventData.isValid = eventData.isValid && form.valid();
            eventData.isValid = eventData.isValid && detailsForm.valid();

            $('body').trigger('validateRequestQuoteForm', eventData);

            if (eventData.isValid) { 
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'remarks')
                    .attr('value', detailsForm.find('[name="quote_remark"]').val())
                    .appendTo(form);
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'telephones')
                    .attr('value', detailsForm.find('[name="quote_telephone"]').val())
                    .appendTo(form);
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'tels')
                    .attr('value', detailsForm.find('[name="quote_tel"]').val())
                    .appendTo(form);
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'matriculefiscales')
                    .attr('value', detailsForm.find('[name="quote_matriculefiscale"]').val())
                    .appendTo(form);
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'societes')
                    .attr('value', detailsForm.find('[name="quote_societe"]').val())
                    .appendTo(form);
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'update_cart_action')
                    .attr('value', 'submit')
                    .appendTo(form);
                $('<input />').attr('type', 'hidden')
                    .attr('name', 'email')
                    .attr('value', detailsForm.find('[name="username"]').val())
                    .appendTo(form);

                detailsForm.find('input, textarea, select').each(function (index, input) {
                    var newInput = $('<input />').attr('type', 'hidden')
                        .attr('name', $(input).attr('name'))
                        .attr('value', $(input).val())
                        .appendTo(form);
                    if ($(input).attr('type') === 'file') {
                        newInput.attr('type', 'file');
                        newInput.files = input.files;
                        $(input).removeAttr('name');
                        $('[name="' + newInput.attr('name') + '"]')[0].files = input.files;
                    }
                });

                $(element).attr('disabled', true);

                $('body').trigger('beforeSubmitRequestQuoteForm', {form: form});

                form.submit();
            }
        });
    };
});
