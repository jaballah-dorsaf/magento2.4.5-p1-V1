var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Mytek_CheckoutCustomField/js/model/shipping-save-processor/default'
        }
    }
};
