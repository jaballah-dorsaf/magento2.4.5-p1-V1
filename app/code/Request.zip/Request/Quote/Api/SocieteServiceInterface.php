<?php

namespace Request\Quote\Api;

/**
 * Interface SocieteServiceInterface
 */
interface SocieteServiceInterface
{
    /**
     * @param string $societe
     *
     * @return void
     */
    public function save($societe);
} 
