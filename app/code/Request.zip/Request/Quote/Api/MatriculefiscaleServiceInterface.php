<?php

namespace Request\Quote\Api;

/**
 * Interface MatriculefiscaleServiceInterface
 */
interface MatriculefiscaleServiceInterface
{
    /**
     * @param string $matriculefiscale
     *
     * @return void
     */
    public function save($matriculefiscale);
} 
