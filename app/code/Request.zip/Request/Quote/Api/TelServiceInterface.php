<?php

namespace Request\Quote\Api;

/**
 * Interface TelServiceInterface
 */
interface TelServiceInterface
{
    /**
     * @param string $tel
     *
     * @return void
     */
    public function save($tel);
} 
