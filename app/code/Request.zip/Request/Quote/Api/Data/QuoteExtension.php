<?php

declare(strict_types=1);

namespace Request\Quote\Api\Data;

class QuoteExtension extends \Magento\Quote\Api\Data\CartExtension implements QuoteExtensionInterface
{

}
