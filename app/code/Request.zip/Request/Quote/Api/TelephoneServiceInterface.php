<?php

namespace Request\Quote\Api;

/**
 * Interface TelephoneServiceInterface
 */
interface TelephoneServiceInterface
{
    /**
     * @param string $telephone
     *
     * @return void
     */
    public function save($telephone);
} 
